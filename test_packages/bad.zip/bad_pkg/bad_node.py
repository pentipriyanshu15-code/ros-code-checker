def broken():
    print("Not a ROS node")

